class StudentAdditionalFieldOption < ActiveRecord::Base

  belongs_to :student_additional_field

  
end
