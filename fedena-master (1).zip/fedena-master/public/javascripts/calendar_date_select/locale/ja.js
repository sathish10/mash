Date.weekdays = $w("日 月 火 水 木 金 土");
Date.months = $w("一月 二月 三月 四月 五月 六月 七月 八月 九月 十月 十一月 十二月" );

Date.first_day_of_week = 1;

_translations = {
  "OK": "良い",
  "Now": "現在",
  "Clear": "クリア",
  "Today": "今日は"
}