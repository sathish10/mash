Date.weekdays = $w('L Ma Me J V S D');
Date.months = $w('Janvier Février Mars Avril Mai Juin Juillet Août Septembre Octobre Novembre Décembre');

Date.first_day_of_week = 1;

_translations = {
  "OK": "OK",
  "Now": "Maintenant",
  "Today": "Aujourd'hui",
  "Clear": "Effacer",
}
